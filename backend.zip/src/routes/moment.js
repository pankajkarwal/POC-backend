const express = require('express')
const MomentController = require('./../controllers/MomentController')
const multer  = require('multer')
const upload = multer({ dest: __dirname + '/uploads/' })

const router = express.Router();
const momentController = new MomentController();

router.post('/add',upload.single('fileName'), momentController.saveMoment)

router.post('/uploadFile',upload.single('fileName'), momentController.uploadFile)

module.exports = router;