const express = require('express')
//import UserController from './../controllers/UserController';
const UserController = require('./../controllers/UserController')

const router = express.Router();
const userController = new UserController();

router.post('/add', userController.saveUser)

module.exports = router;