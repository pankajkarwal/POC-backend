const express = require('express')
var router = express.Router();

router.get('/', function(req, res, next) {
  res.end("Welcome to backend");
});

module.exports = router;
