const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");

const momentSchema = mongoose.Schema({
    title: {
        type: String,
        unique: true,
        trim: true
    },
    tag: {
        type: String,
        trim: true
    },
    fileName: {
        type: String,
        trim: true
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: false
    }
})

momentSchema.plugin(uniqueValidator);
mongoose.pluralize(null); // Disabling making table name plural

module.exports = mongoose.model('moment_master', momentSchema);