//import UserModel from '../models/UserMaster'
const MomentModel = require('../models/MomentMaster')
const constants = require('../utils/constants')
const bcrypt = require('bcrypt');

const multer = require('multer')
const response = {
    status: 200,
    data: [],
    message: null
};

const sendError = (err, res) => {
    response.status = 501
    response.message = typeof err == 'object' ? err.message : err
    res.status(501).json(response)
};
var storage = multer.diskStorage({
    destination: function (req, file, cb) {

        // Uploads is the Upload_folder_name
        cb(null, __dirname + "/uploads")
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + "-" + Date.now() + ".jpg")
    }
})
const maxSize = 1 * 1000 * 1000;
var upload = multer({
    storage: storage,
    limits: { fileSize: maxSize },
    fileFilter: function (req, file, cb) {

        // Set the filetypes, it is optional
        var filetypes = /jpeg|jpg|png/;
        var mimetype = filetypes.test(file.mimetype);

        var extname = filetypes.test(path.extname(
            file.originalname).toLowerCase());

        if (mimetype && extname) {
            return cb(null, true);
        }

        cb("Error: File upload only supports the "
            + "following filetypes - " + filetypes);
    }

    // mypic is the name of file attribute
}).single("fileName");

const addMoment = async (req, res) => {
    try {
        // Get moment input
        const { title, tag, fileName } = req.body;

        // Validate moment input
        if (!(title && tag)) {
            res.status(400).send(constants.ERRORS.ALL_INPUTS_REQUIRED);
        }

        // check if user already exist
        // Validate if moment exist in our database
        const oldMoment = await MomentModel.findOne({ title });

        if (oldMoment) {
            return res.status(409).send(constants.ERRORS.MOMENT_EXISTS);
        }
        // File Uploading

//         upload(req, res, function (err) {
// console.log("Comming")
//             if (err) {

//                 // ERROR occurred (here it can be occurred due
//                 // to uploading image of size greater than
//                 // 1MB or uploading different file type)
//                 res.send(err)
//             }
//             else {

//                 // SUCCESS, image successfully uploaded
//                 res.send("Success, Image uploaded!")
//             }
//         })
        // Create user in our database
        const moment = await MomentModel.create({
            title,
            tag,
            fileName
        });


        // return new user
        res.status(201).json(moment);
    } catch (err) {
        console.log(err);
    }
    // Our register logic ends here

}



module.exports = { addMoment }

