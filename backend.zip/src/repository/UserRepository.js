//import UserModel from '../models/UserMaster'
const UserModel = require('../models/UserMaster')
const constants = require('../utils/constants')
const bcrypt = require('bcrypt');
const jwt = require("jsonwebtoken");


const response = {
    status: 200,
    data: [],
    message: null
};

const sendError = (err, res) => {
    response.status = 501
    response.message = typeof err == 'object' ? err.message : err
    res.status(501).json(response)
};



const addUser = async (req, res) => {
    // Our register logic starts here
    try {
        // Get user input
        const { first_name, last_name, email, password,mobile,city } = req.body;

        // Validate user input
        if (!(email && password && first_name && last_name && city && mobile)) {
            res.status(400).send(constants.ERRORS.ALL_INPUTS_REQUIRED);
        }

        // check if user already exist
        // Validate if user exist in our database
        const oldUser = await UserModel.findOne({ email });

        if (oldUser) {
            return res.status(409).send(constants.ERRORS.USER_EXISTS_LOGIN);
        }

        //Encrypt user password
        const encryptedPassword = await bcrypt.hash(password, constants.SECURITY.HASH_ROUND_STRING_LENGTH);

        // Create user in our database
        const user = await UserModel.create({
            first_name,
            last_name,
            email: email.toLowerCase(), // sanitize: convert email to lowercase
            password: encryptedPassword,
            mobile:mobile,
            city:city
        });

       
        // return new user
        res.status(201).json(user);
    } catch (err) {
        console.log(err);
    }
    // Our register logic ends here

}


module.exports= { addUser} 

