const users = require("../repository/UserRepository")
class UserController{
    saveUser = async(req,res)=>{
        let user = await users.addUser(req,res);
        return user;
    }
    
}
module.exports = UserController
