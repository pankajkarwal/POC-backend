const moments = require("../repository/MomentRepository")
class MomentController{
    saveMoment = async(req,res)=>{
        let moment = await moments.addMoment(req,res);
        return moment;
    }
    uploadFile = async(req,res) => {
        const fileUpload =""
        return fileUpload;
    }
    
}
module.exports = MomentController
