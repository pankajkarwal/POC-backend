const createError = require('http-errors')
const express = require('express')
const path = require('path')
const cookieParser = require('cookie-parser')
const bodyParser = require('body-parser')
const logger = require('morgan')
const cors = require('cors')

// const dotenv = require('dotenv');
// dotenv.config()

const http = require("http");
const app = require("./app");
const server = http.createServer(app);

const { API_PORT } = process.env;
const port = process.env.PORT || API_PORT;

// server listening 
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});





app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(function (req, res, next) {
  if (req.get("x-amz-sns-message-type")) {
    req.headers["content-type"] = "application/json";
  }
  next();
});
const indexRouter = require('./routes/index')
const userRouter = require('./routes/user')
const momentRouter = require('./routes/moment')

app.use(
  cors({
    origin: "*",
    methods: ["PUT", "POST", "GET", "DELETE", "OPTIONS", "PATCH"],
    allowedHeaders: [
      "Origin, X-Requested-With, Content-Type, Accept, Authorization, X-IDENTITY",
    ],
  })
);
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'jade')
app.use(logger('dev'))
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(cookieParser())

 app.use('/moment', momentRouter)
 app.use('/user', userRouter)
app.use('/', indexRouter)


module.exports = app